/* 
declarar 3 variables con valores numéricos imprimir el resultado de la suma de las 3 variables a través de un alert
 */
let v1;
v1 = 3;
let v2 = 4;
let v3 = 6;
v1=4;
alert(v1+v2+v3);


/* 
 declarar 2 variables con valores numéricos 
 
 declarar una variable llamada resultado que contenga el producto de las dos variables anteriores

 imprimir en un alert la variable resultado
 */
let va1 = 5;
let va2 = 2;
let resultado = va1 * va2;
va1=10;
alert(resultado);

//
