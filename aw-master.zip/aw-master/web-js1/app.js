let resultado;

resultado = confirm("¿Quieres que te salude?");

if (resultado == true) {
    alert("Hola");
}else{
    alert("Eres un desagradecido!");
}
alert("fin del progama");



