// alert("Hola mundo");

//Comentario de una línea

/*
Esto es 
un comentario multilínea
*/

/* Esto es un comentario */

// Tipos de datos

// Tipo cadena de texto o string
// alert("Esto es una cadena de texto");
// alert('Esto también es una cadena de texto');
// alert("I'm the \"teacher\"");
// alert('I\'m the teacher');

// Tipo número entero
// se pueden usar operadores aritméticos
// alert(2+3);
// alert(2-3);
// alert(2*3);
// alert(2/3);

// Tipo número decimal
// se pueden usar operadores aritméticos
// alert(2.5+3.1);
// alert(2.7-3.5);
// alert(2*3.2);
// alert(2.87/3.5);

// Tipo booleano
// true false
// operaciones lógicas && ||
// alert(true && true);
// alert(false || true);

