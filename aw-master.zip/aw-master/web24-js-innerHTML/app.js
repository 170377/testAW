alert("Hola");
let miParrafo = document.getElementById("idParrafo");
miParrafo.innerHTML = "Este es el valor nuevo del contenido";