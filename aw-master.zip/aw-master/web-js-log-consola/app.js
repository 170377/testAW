console.log("Hola mundo");
console.error("Esto es la consola de error");

/*Esto es una declaración de una constante*/
const saludo = "hola";

// Esta línea da error, porque a una constante no se le puede cambiar el valor
saludo = "adios";